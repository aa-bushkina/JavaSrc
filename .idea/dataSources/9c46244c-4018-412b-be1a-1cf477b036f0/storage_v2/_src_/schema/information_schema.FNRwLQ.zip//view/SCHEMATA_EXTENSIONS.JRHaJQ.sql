create view SCHEMATA_EXTENSIONS as
-- missing source code
;

