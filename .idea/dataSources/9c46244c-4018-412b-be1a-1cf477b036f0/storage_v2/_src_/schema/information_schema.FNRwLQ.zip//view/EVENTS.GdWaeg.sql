create view EVENTS as
-- missing source code
;

