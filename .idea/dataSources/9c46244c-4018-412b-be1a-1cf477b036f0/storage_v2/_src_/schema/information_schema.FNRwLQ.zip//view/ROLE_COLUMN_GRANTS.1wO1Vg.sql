create view ROLE_COLUMN_GRANTS as
-- missing source code
;

