create view SCHEMATA as
-- missing source code
;

