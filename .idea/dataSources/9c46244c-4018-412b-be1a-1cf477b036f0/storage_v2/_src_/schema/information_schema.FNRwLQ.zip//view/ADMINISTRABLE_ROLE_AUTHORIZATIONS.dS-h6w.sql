create view ADMINISTRABLE_ROLE_AUTHORIZATIONS as
-- missing source code
;

