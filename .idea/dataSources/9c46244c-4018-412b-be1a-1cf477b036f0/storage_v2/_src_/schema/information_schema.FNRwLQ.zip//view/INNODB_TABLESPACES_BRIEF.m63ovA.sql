create view INNODB_TABLESPACES_BRIEF as
-- missing source code
;

