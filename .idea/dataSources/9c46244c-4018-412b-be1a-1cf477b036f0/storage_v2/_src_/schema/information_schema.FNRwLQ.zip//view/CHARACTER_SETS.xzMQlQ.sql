create view CHARACTER_SETS as
-- missing source code
;

