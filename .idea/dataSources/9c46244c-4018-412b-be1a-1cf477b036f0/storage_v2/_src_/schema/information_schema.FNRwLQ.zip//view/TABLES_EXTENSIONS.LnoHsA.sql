create view TABLES_EXTENSIONS as
-- missing source code
;

