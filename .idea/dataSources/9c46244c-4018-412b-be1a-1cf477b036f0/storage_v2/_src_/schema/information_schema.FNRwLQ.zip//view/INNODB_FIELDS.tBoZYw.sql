create view INNODB_FIELDS as
-- missing source code
;

