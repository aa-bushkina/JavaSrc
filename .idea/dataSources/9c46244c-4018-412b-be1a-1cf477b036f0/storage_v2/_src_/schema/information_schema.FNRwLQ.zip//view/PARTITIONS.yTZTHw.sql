create view PARTITIONS as
-- missing source code
;

