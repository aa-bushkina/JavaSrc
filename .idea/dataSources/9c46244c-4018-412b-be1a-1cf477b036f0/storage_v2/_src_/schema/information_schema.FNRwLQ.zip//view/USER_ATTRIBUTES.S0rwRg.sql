create view USER_ATTRIBUTES as
-- missing source code
;

