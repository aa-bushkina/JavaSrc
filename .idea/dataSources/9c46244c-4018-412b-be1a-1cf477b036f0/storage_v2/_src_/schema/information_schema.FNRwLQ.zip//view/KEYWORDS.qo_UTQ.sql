create view KEYWORDS as
-- missing source code
;

