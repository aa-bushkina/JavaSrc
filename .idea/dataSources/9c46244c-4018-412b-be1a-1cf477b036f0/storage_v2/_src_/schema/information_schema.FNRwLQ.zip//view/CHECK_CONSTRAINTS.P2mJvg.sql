create view CHECK_CONSTRAINTS as
-- missing source code
;

