create view VIEWS as
-- missing source code
;

