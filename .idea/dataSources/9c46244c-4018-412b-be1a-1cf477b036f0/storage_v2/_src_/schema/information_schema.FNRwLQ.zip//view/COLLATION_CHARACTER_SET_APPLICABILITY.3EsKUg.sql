create view COLLATION_CHARACTER_SET_APPLICABILITY as
-- missing source code
;

