create view ST_SPATIAL_REFERENCE_SYSTEMS as
-- missing source code
;

