create view ROUTINES as
-- missing source code
;

