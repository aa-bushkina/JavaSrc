create view ROLE_TABLE_GRANTS as
-- missing source code
;

