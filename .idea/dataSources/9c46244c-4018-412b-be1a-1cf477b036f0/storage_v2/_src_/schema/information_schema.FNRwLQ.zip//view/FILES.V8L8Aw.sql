create view FILES as
-- missing source code
;

