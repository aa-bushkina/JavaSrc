create view TRIGGERS as
-- missing source code
;

