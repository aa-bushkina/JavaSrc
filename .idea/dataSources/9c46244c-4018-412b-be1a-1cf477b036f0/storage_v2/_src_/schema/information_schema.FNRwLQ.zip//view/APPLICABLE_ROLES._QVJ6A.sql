create view APPLICABLE_ROLES as
-- missing source code
;

