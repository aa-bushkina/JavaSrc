create view ENABLED_ROLES as
-- missing source code
;

