create view TABLESPACES_EXTENSIONS as
-- missing source code
;

