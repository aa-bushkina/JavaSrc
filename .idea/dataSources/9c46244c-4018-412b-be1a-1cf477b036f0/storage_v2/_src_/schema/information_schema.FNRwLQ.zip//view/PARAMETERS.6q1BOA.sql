create view PARAMETERS as
-- missing source code
;

