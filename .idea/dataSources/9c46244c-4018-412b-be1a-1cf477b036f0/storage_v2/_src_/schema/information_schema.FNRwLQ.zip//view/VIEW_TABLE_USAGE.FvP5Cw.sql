create view VIEW_TABLE_USAGE as
-- missing source code
;

