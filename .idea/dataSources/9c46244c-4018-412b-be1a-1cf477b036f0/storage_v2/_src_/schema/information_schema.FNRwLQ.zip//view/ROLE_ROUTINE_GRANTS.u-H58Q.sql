create view ROLE_ROUTINE_GRANTS as
-- missing source code
;

