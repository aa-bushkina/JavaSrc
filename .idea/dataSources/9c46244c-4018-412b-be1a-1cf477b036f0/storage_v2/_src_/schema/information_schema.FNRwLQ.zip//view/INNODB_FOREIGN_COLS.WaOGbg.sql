create view INNODB_FOREIGN_COLS as
-- missing source code
;

