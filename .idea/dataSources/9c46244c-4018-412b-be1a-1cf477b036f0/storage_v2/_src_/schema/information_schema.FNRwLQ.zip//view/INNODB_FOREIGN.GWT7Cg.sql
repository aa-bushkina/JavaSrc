create view INNODB_FOREIGN as
-- missing source code
;

