create view RESOURCE_GROUPS as
-- missing source code
;

