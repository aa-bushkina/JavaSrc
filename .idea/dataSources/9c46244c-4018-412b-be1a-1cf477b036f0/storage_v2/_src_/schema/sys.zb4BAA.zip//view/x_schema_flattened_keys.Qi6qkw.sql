create definer = `mysql.sys`@localhost view x$schema_flattened_keys as
-- missing source code
;

