create definer = `mysql.sys`@localhost view schema_table_statistics as
-- missing source code
;

