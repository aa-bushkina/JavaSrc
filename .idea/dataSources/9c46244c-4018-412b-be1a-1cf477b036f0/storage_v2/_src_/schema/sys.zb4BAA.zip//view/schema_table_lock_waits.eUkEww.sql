create definer = `mysql.sys`@localhost view schema_table_lock_waits as
-- missing source code
;

