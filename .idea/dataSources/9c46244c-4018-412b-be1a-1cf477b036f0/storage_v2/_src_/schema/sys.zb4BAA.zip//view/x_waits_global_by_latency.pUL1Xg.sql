create definer = `mysql.sys`@localhost view x$waits_global_by_latency as
-- missing source code
;

