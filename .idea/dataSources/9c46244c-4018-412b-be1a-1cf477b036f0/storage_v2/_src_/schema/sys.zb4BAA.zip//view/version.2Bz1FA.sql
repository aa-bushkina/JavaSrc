create definer = `mysql.sys`@localhost view version as
-- missing source code
;

