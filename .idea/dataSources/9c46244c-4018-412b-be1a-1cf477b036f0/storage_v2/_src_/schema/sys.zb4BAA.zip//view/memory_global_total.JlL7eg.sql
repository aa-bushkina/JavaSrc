create definer = `mysql.sys`@localhost view memory_global_total as
-- missing source code
;

