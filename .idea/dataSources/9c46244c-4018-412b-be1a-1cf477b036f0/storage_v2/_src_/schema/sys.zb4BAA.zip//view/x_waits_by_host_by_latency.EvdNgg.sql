create definer = `mysql.sys`@localhost view x$waits_by_host_by_latency as
-- missing source code
;

