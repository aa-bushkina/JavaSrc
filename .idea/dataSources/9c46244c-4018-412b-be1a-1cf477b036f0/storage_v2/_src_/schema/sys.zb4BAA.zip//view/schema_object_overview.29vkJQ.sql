create definer = `mysql.sys`@localhost view schema_object_overview as
-- missing source code
;

