create definer = `mysql.sys`@localhost view x$wait_classes_global_by_latency as
-- missing source code
;

