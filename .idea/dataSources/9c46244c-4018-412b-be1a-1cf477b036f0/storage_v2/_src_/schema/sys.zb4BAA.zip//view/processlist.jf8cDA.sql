create definer = `mysql.sys`@localhost view processlist as
-- missing source code
;

