create definer = `mysql.sys`@localhost view schema_table_statistics_with_buffer as
-- missing source code
;

