create definer = `mysql.sys`@localhost view schema_index_statistics as
-- missing source code
;

