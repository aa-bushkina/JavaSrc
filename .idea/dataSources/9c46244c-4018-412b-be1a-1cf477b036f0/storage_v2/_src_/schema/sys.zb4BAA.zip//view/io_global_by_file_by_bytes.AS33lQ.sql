create definer = `mysql.sys`@localhost view io_global_by_file_by_bytes as
-- missing source code
;

