create definer = `mysql.sys`@localhost view x$schema_index_statistics as
-- missing source code
;

