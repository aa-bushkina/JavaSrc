create definer = `mysql.sys`@localhost view host_summary_by_statement_type as
-- missing source code
;

