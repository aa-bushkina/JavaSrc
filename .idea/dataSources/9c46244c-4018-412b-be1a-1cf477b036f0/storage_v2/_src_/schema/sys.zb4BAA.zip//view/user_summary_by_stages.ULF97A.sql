create definer = `mysql.sys`@localhost view user_summary_by_stages as
-- missing source code
;

