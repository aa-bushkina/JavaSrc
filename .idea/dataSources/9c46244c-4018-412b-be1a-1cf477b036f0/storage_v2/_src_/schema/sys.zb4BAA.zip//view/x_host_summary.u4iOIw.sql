create definer = `mysql.sys`@localhost view x$host_summary as
-- missing source code
;

