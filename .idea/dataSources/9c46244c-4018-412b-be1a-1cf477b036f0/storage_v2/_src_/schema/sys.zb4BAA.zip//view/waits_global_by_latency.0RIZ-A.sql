create definer = `mysql.sys`@localhost view waits_global_by_latency as
-- missing source code
;

