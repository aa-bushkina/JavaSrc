create definer = `mysql.sys`@localhost view memory_by_thread_by_current_bytes as
-- missing source code
;

