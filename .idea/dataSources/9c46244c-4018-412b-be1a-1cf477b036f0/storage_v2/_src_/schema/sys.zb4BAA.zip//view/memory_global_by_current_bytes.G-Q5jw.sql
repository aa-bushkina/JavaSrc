create definer = `mysql.sys`@localhost view memory_global_by_current_bytes as
-- missing source code
;

