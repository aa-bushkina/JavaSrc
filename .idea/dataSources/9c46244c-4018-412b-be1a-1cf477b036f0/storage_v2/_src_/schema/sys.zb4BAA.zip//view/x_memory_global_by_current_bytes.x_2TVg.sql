create definer = `mysql.sys`@localhost view x$memory_global_by_current_bytes as
-- missing source code
;

