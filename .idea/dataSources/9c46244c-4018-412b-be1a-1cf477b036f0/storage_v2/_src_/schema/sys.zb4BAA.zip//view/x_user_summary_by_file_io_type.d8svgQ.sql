create definer = `mysql.sys`@localhost view x$user_summary_by_file_io_type as
-- missing source code
;

