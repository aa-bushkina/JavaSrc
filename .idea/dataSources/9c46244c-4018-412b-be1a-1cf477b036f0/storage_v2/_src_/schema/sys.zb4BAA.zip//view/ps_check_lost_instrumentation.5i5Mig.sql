create definer = `mysql.sys`@localhost view ps_check_lost_instrumentation as
-- missing source code
;

