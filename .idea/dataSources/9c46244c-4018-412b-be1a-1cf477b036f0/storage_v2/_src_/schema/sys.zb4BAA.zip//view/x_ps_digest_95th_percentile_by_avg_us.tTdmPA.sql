create definer = `mysql.sys`@localhost view x$ps_digest_95th_percentile_by_avg_us as
-- missing source code
;

