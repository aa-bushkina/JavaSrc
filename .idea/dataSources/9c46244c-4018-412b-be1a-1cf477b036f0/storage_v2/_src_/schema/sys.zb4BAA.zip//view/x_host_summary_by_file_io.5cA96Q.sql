create definer = `mysql.sys`@localhost view x$host_summary_by_file_io as
-- missing source code
;

