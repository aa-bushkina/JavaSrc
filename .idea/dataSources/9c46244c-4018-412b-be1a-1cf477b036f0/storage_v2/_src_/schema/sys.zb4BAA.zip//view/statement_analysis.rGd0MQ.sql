create definer = `mysql.sys`@localhost view statement_analysis as
-- missing source code
;

