create definer = `mysql.sys`@localhost view x$session as
-- missing source code
;

