create definer = `mysql.sys`@localhost view session as
-- missing source code
;

