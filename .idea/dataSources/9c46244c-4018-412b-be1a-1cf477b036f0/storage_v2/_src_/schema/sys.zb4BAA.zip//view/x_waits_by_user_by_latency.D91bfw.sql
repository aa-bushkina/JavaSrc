create definer = `mysql.sys`@localhost view x$waits_by_user_by_latency as
-- missing source code
;

