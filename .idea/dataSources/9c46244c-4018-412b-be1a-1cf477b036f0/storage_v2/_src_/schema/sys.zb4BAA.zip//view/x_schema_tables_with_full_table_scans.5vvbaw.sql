create definer = `mysql.sys`@localhost view x$schema_tables_with_full_table_scans as
-- missing source code
;

