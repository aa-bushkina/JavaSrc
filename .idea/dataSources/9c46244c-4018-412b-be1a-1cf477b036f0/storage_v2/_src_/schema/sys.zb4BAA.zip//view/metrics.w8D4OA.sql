create definer = `mysql.sys`@localhost view metrics as
-- missing source code
;

