create definer = `mysql.sys`@localhost view schema_unused_indexes as
-- missing source code
;

