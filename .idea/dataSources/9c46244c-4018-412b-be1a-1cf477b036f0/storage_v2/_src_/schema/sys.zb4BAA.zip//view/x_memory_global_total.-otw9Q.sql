create definer = `mysql.sys`@localhost view x$memory_global_total as
-- missing source code
;

