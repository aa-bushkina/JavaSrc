create definer = `mysql.sys`@localhost view innodb_lock_waits as
-- missing source code
;

