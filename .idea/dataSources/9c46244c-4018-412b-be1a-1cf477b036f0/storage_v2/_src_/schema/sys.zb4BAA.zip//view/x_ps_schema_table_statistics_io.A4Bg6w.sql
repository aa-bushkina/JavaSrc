create definer = `mysql.sys`@localhost view x$ps_schema_table_statistics_io as
-- missing source code
;

