create definer = `mysql.sys`@localhost view io_by_thread_by_latency as
-- missing source code
;

