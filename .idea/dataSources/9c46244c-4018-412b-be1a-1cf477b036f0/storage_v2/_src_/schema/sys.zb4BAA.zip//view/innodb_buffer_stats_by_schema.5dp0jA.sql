create definer = `mysql.sys`@localhost view innodb_buffer_stats_by_schema as
-- missing source code
;

