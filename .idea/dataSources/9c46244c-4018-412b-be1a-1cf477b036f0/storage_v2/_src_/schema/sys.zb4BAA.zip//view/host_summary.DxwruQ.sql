create definer = `mysql.sys`@localhost view host_summary as
-- missing source code
;

