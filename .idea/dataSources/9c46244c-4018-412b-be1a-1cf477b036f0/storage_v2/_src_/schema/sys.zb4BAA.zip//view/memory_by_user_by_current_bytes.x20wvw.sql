create definer = `mysql.sys`@localhost view memory_by_user_by_current_bytes as
-- missing source code
;

