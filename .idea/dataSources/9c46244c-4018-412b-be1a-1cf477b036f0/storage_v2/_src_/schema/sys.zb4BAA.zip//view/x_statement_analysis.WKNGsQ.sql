create definer = `mysql.sys`@localhost view x$statement_analysis as
-- missing source code
;

