create definer = `mysql.sys`@localhost view session_ssl_status as
-- missing source code
;

