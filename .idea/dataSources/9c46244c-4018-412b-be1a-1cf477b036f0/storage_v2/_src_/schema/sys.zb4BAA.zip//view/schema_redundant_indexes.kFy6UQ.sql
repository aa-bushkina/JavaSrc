create definer = `mysql.sys`@localhost view schema_redundant_indexes as
-- missing source code
;

