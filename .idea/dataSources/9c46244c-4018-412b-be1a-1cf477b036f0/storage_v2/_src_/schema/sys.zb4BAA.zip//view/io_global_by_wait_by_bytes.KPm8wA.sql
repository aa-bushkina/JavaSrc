create definer = `mysql.sys`@localhost view io_global_by_wait_by_bytes as
-- missing source code
;

