create definer = `mysql.sys`@localhost view latest_file_io as
-- missing source code
;

