create definer = `mysql.sys`@localhost view statements_with_temp_tables as
-- missing source code
;

