create definer = `mysql.sys`@localhost view statements_with_errors_or_warnings as
-- missing source code
;

