create definer = `mysql.sys`@localhost view memory_by_host_by_current_bytes as
-- missing source code
;

