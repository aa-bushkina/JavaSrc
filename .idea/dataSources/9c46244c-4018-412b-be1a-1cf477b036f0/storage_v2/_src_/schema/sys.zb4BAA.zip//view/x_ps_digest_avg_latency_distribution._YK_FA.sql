create definer = `mysql.sys`@localhost view x$ps_digest_avg_latency_distribution as
-- missing source code
;

