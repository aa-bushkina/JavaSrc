create definer = `mysql.sys`@localhost view x$statements_with_errors_or_warnings as
-- missing source code
;

