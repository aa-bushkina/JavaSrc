create definer = `mysql.sys`@localhost view schema_auto_increment_columns as
-- missing source code
;

