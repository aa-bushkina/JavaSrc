create definer = `mysql.sys`@localhost view user_summary as
-- missing source code
;

