create definer = `mysql.sys`@localhost view innodb_buffer_stats_by_table as
-- missing source code
;

