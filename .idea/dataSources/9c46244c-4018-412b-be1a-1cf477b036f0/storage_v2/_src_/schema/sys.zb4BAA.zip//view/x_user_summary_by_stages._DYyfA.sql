create definer = `mysql.sys`@localhost view x$user_summary_by_stages as
-- missing source code
;

