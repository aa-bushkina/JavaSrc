create definer = `mysql.sys`@localhost view waits_by_user_by_latency as
-- missing source code
;

