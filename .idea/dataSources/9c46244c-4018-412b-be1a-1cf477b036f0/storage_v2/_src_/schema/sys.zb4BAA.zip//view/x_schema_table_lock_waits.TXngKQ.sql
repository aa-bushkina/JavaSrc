create definer = `mysql.sys`@localhost view x$schema_table_lock_waits as
-- missing source code
;

