create definer = `mysql.sys`@localhost view x$processlist as
-- missing source code
;

