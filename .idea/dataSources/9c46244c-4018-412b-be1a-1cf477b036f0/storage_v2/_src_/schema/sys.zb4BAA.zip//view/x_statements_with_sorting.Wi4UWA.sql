create definer = `mysql.sys`@localhost view x$statements_with_sorting as
-- missing source code
;

